from flask import Flask, request

app = Flask(__name__)

@app.route('/github-webhook', methods=['POST'])
def github_webhook():
    event = request.headers.get('X-GitHub-Event', 'ping')
    data = request.json
    print(f"Received {event}: {data}")
    # Add custom alerting or logging here
    return '', 204

if __name__ == '__main__':
    app.run(port=8080)